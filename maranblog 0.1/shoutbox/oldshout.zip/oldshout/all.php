<html>
<head>
<title>All Tags</title>
<link rel="stylesheet" href="stylesheet.php" type="text/css">
<script language = "JavaScript">
<!-- Begin
function popUp(URL) {
    day = new Date();
    id = day.getTime();
    eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=no,location=0,statusbar=0,menubar=0,resizable=0,width=400,height=150,left = 262,top = 184');");
}
// End -->
</script>
</head>
<body topmargin="0" leftmargin="0">
<b><small>Viewing Archive</small></b><br>
<a href = "javascript:history.go(-1)"><< Back</b></a><br><br>
<?
include("alltag.txt");
?>
</body>
</html>