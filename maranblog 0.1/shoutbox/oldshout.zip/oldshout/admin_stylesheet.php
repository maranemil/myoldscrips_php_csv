BODY	{
			font-family: verdana; 
			color: #000000; 
			font-size: 8pt; 
			SCROLLBAR-BASE-COLOR: #666666; 
			SCROLLBAR-ARROW-COLOR: #FFFFFF;
			}

TD	{
		font-family: verdana; 
		color: #000000; 
		font-size: 8pt;
		}

A:link	{
			text-decoration: none; 
			color: #666666;
			}

A:visited	{
				text-decoration: none;
				color: #666666;
				}

A:hover	 {
			  font-style: normal;
			  color: #000000;
			  text-decoration: none;
			  }

SELECT		{
				font-family:verdana;
				font-size:8pt;
				background:#FFFFFF;
				color:#000000;
				}

INPUT	{
			font-family:verdana;
			font-size:8pt;
			background:#FFFFFF;
			color:#000000;
			}

TEXTAREA	{
				font-family:verdana;
				font-size:8pt;
				background:#FFFFFF;
				color:#000000;
				}

.menu	{
			font-family: Verdana; 
			color: #000000; 
			font-size: 8pt;
			}

A:link.menu	{
					text-decoration: none; 
					color: #666666;
					}

A:visited.menu	{
						text-decoration: none; 
						color: #666666;
						}

A:hover.menu	{
						text-decoration: none; 
						color: #AAAAAA; 
						}

.xtra {
		background:#666666;
		color:#FFFFFF; 
		font-family:verdana;
		font-size:8pt; 
		}

