<html>
<head>
<title>CJ Tag Board V3.0</title>
</head>
<body>
<? include("htmlcode.dat"); ?>
</body>
</html>